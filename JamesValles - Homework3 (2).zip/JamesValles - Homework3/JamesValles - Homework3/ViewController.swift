//
//  ViewController.swift
//  JamesValles - Homework3
//
//  Created by James Valles on 1/25/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit


//calculator handles decimal and non-decimal numbers, added functionality to display an int or a float based on result value.

class ViewController: UIViewController {
    
    //Initialize variables.
    var current: Float = 0
    var previous: Float = 0
    var result: Float = 0
    
    //Results label
    @IBOutlet weak var resultsLabel: UILabel!
    
    //IBAction for number buttons.
    @IBAction func digits(_ sender: UIButton) {
        
        //Label with include just a number with no decimal point. Display digits pressed on label and save to current.
        if (sender.tag != 11){
        resultsLabel.text = resultsLabel.text! + sender.currentTitle!  
        current = Float(resultsLabel.text!)!
        }
        
        //Label will include number with decimal point. Display digits pressed on label and save to current.
        if (sender.tag == 11){
            resultsLabel.text = resultsLabel.text! + "."
            current = Float(resultsLabel.text!)!
        }
    }
    
    //Function to add numbers.
    func add() -> Float {
        result += current + previous
        return result
    }
    
    //Function to clear calculator.
    func clear(){
        resultsLabel.text = ""
        current = 0
        previous = 0
        result = 0
    }
    
    
    //IBAction for operators +, =
    @IBAction func operators(_ sender: UIButton) {
        
                //if the + button is pressed, set current number to previous number, clear label and current number
                if (resultsLabel.text != "" && sender.tag != 13 && sender.tag != 14){
                   if(sender.tag == 12 ){
                  previous += current
                  current = 0
                  resultsLabel.text = ""
                }
        }
        
                //If the C (clear) button is presssed invoke invoke clear function.
                if(sender.tag == 13){
                    clear()
        }
        
                //If = (equal) button is pressed, invoke add function, convert result to string, determine if number if an intent, or decimal number and display number in label, and clear current and previous.
                if(sender.tag == 14){
                    let displayResult : Float =  add()
                    
                    if (ceilf(displayResult) == displayResult){
                        resultsLabel.text = String(Int(displayResult))
                    } else {
                        resultsLabel.text = String(displayResult)
                    }
                    
                    current = 0
                    previous = 0
                }
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

                //This changes the Status Bar style to light, so that the time and batter can display on a black background
    override var preferredStatusBarStyle: UIStatusBarStyle {
        return .lightContent
    }


}

