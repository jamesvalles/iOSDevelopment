//
//  LandscapeViewController.swift
//  JamesValles - Homework3
//
//  Created by James Valles on 1/28/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class LandscapeViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}
