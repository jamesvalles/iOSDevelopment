//
//  DVRController.swift
//  JamesValles Asssignment6 _ Revised Version
//
//  Created by James Valles on 2/24/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class DVRController: UIViewController {
    
    @IBOutlet weak var powerLabel: UILabel!
    @IBOutlet weak var currentStatusLabel: UILabel!
    @IBOutlet weak var powerSwitch: UISwitch!
    @IBOutlet weak var tvScreen: UIImageView!
    @IBOutlet var dvrButtons: [UIBarButtonItem]!
    
    var currentState: String = "Stopped"
    var previousState: String = "Stopped"
    
    
    @IBAction func tvPowerSwitch(_ sender: Any) {
        if powerSwitch.isOn {
            currentStatusLabel.text = "Stopped"
            tvScreen.image = UIImage(named: "tvon.jpg")
            currentState = "Stopped"
            powerLabel.text = "ON"
            for button in dvrButtons {
                button.isEnabled = true
            }
        } else {
            tvScreen.image = UIImage(named: "")
            currentStatusLabel.text = "DVR OFF"
            powerLabel.text = "OFF"
            for button in dvrButtons {
                button.isEnabled = false
            }
        }
    }
    
    @IBAction func play(_ sender: Any) {
        if currentState != "Recording" {
            currentState = "Playing"
            previousState = "Playing"
            currentStatusLabel.text = "Playing"
        } else {
            popup("Playing", "Playing")
            previousState = currentState
        }
        
    }
    
    @IBAction func pause(_ sender: Any) {
        if ["Playing","Paused","Fast Forwarding","Fast Rewinding"].contains(currentState)  {
            previousState = currentState
            currentState = "Paused"
            currentStatusLabel.text = "Paused"
        } else {
            popup("Paused", currentState)
        }
    }
    
    @IBAction func rewind(_ sender: Any) {
        if ["Playing","Paused","Fast Forwarding","Fast Rewinding"].contains(currentState) {
            previousState = currentState
            currentState = "Fast Rewinding"
            currentStatusLabel.text = "Fast Rewinding"
        } else {
            popup("Fast Rewinding", currentState)
            
        }
    }
    
    @IBAction func fastforward(_ sender: Any) {
        if ["Playing","Paused","Fast Forwarding","Fast Rewinding"].contains(currentState) {
            previousState = currentState
            currentState = "Fast Forwarding"
            currentStatusLabel.text = "Fast Forwarding"
        } else {
            popup("Fast Forwarding", currentState)
            
        }
    }
    
    @IBAction func stop(_ sender: Any) {
        previousState = "Stopped"
        currentState = "Stopped"
        currentStatusLabel.text = "Stopped"
    }
    
    @IBAction func record(_ sender: Any) {
        if currentState == "Stopped" {
            previousState = currentState
            currentState = "Recording"
            currentStatusLabel.text = "Recording"
        } else {
            previousState = currentState
            popup("Recording", currentState)
        }
    }
    
    
    func popup(_ tagName: String, _ currentState: String) {
        let title = "WARNING! INVALID ACTION SELECTED"
        let message = "You made an invalid selection - \(tagName). Proceed or cancel the operation."
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        let cancelAction = UIAlertAction(title: "Cancel Operation", style: .destructive) { action in
        }
        
        let confirmAction = UIAlertAction(title: " Proceed", style: .default) { action in
            self.currentStatusLabel.text = tagName
            self.previousState = self.currentState
        
            self.currentState = tagName
            self.showAlert(tagName)
        }
        alertController.addAction(cancelAction)
        alertController.addAction(confirmAction)
        present(alertController, animated: true, completion: nil)
        
    }
    
    func showAlert(_ tagName: String) {
        let alert = UIAlertController(title: "Confirmation", message: "\(self.previousState) state has been stopped, and \(tagName) will proceed", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
            NSLog("The \"OK\" alert occured.")
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        for button in dvrButtons {
            button.isEnabled = false
        }
        
    }
    
}


