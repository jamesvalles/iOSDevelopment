//
//  Data.swift
//  JamesVallesAssignment8
//
//  Created by James Valles on 3/4/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import Foundation

enum Category: String {
    case Entertainment = "entertainment"
    case Politics = "politics"
    case Sports = "sports"
    case News = "news"
    case Business = "business"
}

class Headlines {
    var title: String
    var source: String
    var category: Category
    var description: String
    var img: String
    
    init(title: String, source: String, category: Category, description: String, img: String) {
        self.title = title
        self.source = source
        self.category = category
        self.description = description
        self.img = img
    }
}

let headlines = [
    Headlines(title : "Statue of Liberty",
              category: .News,
               source: "CNN",
               description: "The Statue of Liberty is a figure of Libertas, a robed Roman liberty goddess. She holds a torch above her head with her right hand, and in her left hand carries a tabula ansata inscribed in Roman numerals with JULY IV MDCCLXXVI (July 4, 1776), the date of the U.S. Declaration of Independence. A broken chain lies at her feet as she walks forward. The statue became an icon of freedom and of the United States, and a national park tourism destination. It is a welcoming sight to immigrants arriving from abroad.",
               img: "statue_liberty")
    
]
