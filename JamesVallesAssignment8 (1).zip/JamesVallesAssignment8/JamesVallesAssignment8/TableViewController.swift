//
//  TableViewController.swift
//  JamesVallesAssignment8
//
//  Created by James Valles on 3/4/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class TableViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
}

  

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return newsFeed.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let story = newsFeed[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: story.category.rawValue, for: indexPath) as! NewsTableViewCell
       
        cell.newsHeadline.text = story.title
      //  cell.category.text = story.category.rawValue
        cell.storyImage.image = UIImage(named: story.img)
        cell.source.text = story.category.rawValue
        return cell
       
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destVirtControl = segue.destination as? StoryDetailViewController {
            if let cell = sender as? NewsTableViewCell {
                if let indexpath = self.tableView.indexPath(for: cell) {
                    destVirtControl.data = newsFeed[indexpath.row]
                }
            }
            
        }
    }
    

    
    
}
