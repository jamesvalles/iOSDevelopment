//
//  Story.swift
//  JamesVallesAssignment8
//
//  Created by James Valles on 3/10/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//


import Foundation

enum Category: String {
    case Entertainment = "ENTERTAINMENT"
    case Politics = "POLITICS"
    case Sports = "SPORTS"
    case News = "NEWS"
    case Business = "BUSINESS"
}

class Story {
    var title: String
    var source: String
    var category: Category
    var description: String
    var img: String
    
    init(title: String,category: Category,  source: String, description: String, img: String) {
        self.title = title
        self.category = category
         self.source = source
        self.description = description
        self.img = img
    }
}

let newsFeed = [ Story(title: "About ABC News",
          category: .News,
          source: "ABC NEWS",
          description: "ABC News is the news division of the American Broadcasting Company (ABC), owned by the Disney Media Networks division of The Walt Disney Company. Its flagship program is the daily evening newscast ABC World News Tonight with David Muir; other programs include morning news-talk show Good Morning America, newsmagazine series Nightline, Primetime and 20/20, and Sunday morning political affairs program This Week with George Stephanopoulos.",
          img: "abcnews"),
    
    Story(title: "About A&E",
          category: .Entertainment,
          source: "A&E",
          description: "A&E is an American cable television network. It is the flagship television property of A&E Networks, a joint venture between the Hearst Communications and Disney–ABC Television Group subsidiary of The Walt Disney Company. The network is headquartered in New York City and operates offices in Atlanta, Georgia; Chicago, Illinois; Detroit, Michigan; London, United Kingdom; Los Angeles, California and Stamford, Connecticut.",
          img: "ae"),
    
    Story(title: "About BBC Sports",
          category: .Sports,
          source: "BBC",
          description: "BBC Sport is a department of the BBC North division providing national sports coverage for BBC Television, radio and online. The BBC holds the television and radio UK broadcasting rights to several sports, broadcasting the sport live or alongside flagship analysis programmes such as Match of the Day, Test Match Special, Ski Sunday, Today at Wimbledon and previously Grandstand. Results, analysis and coverage is also added to the BBC Sport Website[1] and through the BBC Red Button interactive television service.",
          img: "bbcsport"),

    Story(title: "BBC News",
          category: .News,
          source: "BBC",
          description: "BBC World News is the BBC's international news and current affairs television channel. It has the largest audience of any channel, with an estimated 99 million viewers weekly in 2015/16, part of the estimated 265 million users of the BBC's four main international news services. Launched on 11 March 1991 as BBC World Service Television outside Europe, its name was changed to BBC World on 16 January 1995 and to BBC World News on 21 April 2008.",
          img: "bbcworldnews"),
    
    Story(title: "About Bravo",
          category: .Entertainment,
          source: "BRAVO",
          description: "Bravo is an American pay television network, launched on December 1, 1980. It is owned by NBCUniversal, a subsidiary of Comcast. The channel originally focused on programming related to fine arts and film; it currently broadcasts several reality television series targeted at 25-54-year-old women as well as the gay community, along with acquired and original dramas, and mainstream theatrically released feature films.",
          img: "bravo"),
    
    Story(title: "About CBS News",
          category: .News,
          source: "CBS",
          description: "CBS News is the news division of American television and radio service CBS. CBS News' broadcasts include the CBS Evening News, CBS This Morning, news magazine programs CBS Sunday Morning, 60 Minutes and 48 Hours, and Sunday morning political affairs program Face the Nation. CBS News Radio produces hourly newscasts for hundreds of radio stations, and also oversees CBS News podcasts like The Takeout Podcast. CBS News also operates a 24-hour digital news network called CBSN.",
          img: "cbsevening"),
    
    Story(title: "CNBC Business",
          category: .Business,
          source: "CNBC",
          description: "CNBC is an American pay television business news channel that is owned by NBCUniversal Broadcast, Cable, Sports and News, a division of NBCUniversal, with both being ultimately owned by Comcast. Headquartered in Englewood Cliffs, New Jersey, the network primarily carries business day coverage of U.S. and international financial markets; following the end of the business day and on non-trading days, CNBC primarily carries financial and business-themed documentaries and reality shows.",
          img: "cnbc"),

    Story(title: "About E!",
          category: .Entertainment,
          source: "NBCUniversal",
          description: "E! was originally launched on July 31, 1987, as Movietime, a service that aired movie trailers, entertainment news, event and awards coverage,and interviews as an early example of a national barker channel. The channel was founded by Larry Namer and Alan Mruvka. Early Movietime hosts included Greg Kinnear, Paula Abdul, Katie Wagner, Julie Moran, Suzanne Kay (daughter of Diahann Carroll), Mark DeCarlo, Sam Rubin and Richard Blade.",
          img: "e"),
    
    Story(title: "About ESPN",
          category: .Sports,
          source: "ESPN",
          description: "ESPN (originally an initialism for Entertainment and Sports Programming Network) is a U.S.-based sports television channel owned by ESPN Inc., a joint venture owned by The Walt Disney Company (80%) and Hearst Communications (20%). The company was founded in 1979 by Bill Rasmussen along with his son Scott Rasmussen and Ed Egan.",
          img: "espn"),

    Story(title: "About FOX News",
          category: .Politics,
          source: "FOX",
          description: "Fox News (officially known as the Fox News Channel, commonly abbreviated to FNC) is an American pay television conservative news channel owned by the Fox News Group, a division of the Fox Corporation. The channel broadcasts primarily from studios at 1211 Avenue of the Americas in New York City. Fox News is provided in 86 countries or overseas territories worldwide, with international broadcasts featuring Fox Extra segments during ad breaks.",
          img: "foxnews"),
    
    Story(title: "About CNN",
          category: .Politics,
          source: "CNN",
          description: "Cable News Network (CNN) is an American news-based pay television channel owned by WarnerMedia News & Sports, a division of AT&T's WarnerMedia. CNN was founded in 1980 by American media proprietor Ted Turner as a 24-hour cable news channel. Upon its launch, CNN was the first television channel to provide 24-hour news coverage, and was the first all-news television channel in the United States.",
          img: "cnn"),
    
    Story(title: "About FOX Sports",
          category: .Sports,
          source: "FOX",
          description: "Fox Sports is the brand name for a number of sports channels, broadcast divisions, programming, and other media around the world that are either controlled or partially owned by the family of Rupert Murdoch, or companies called Scream Factory and Shout! Factory. These assets are held mainly by Fox Corporation, with the exception of the operations in Australia, which are part of News Corp Australia. (21st Century Fox and News Corp are the two companies resulting from the breakup of the larger News Corporation in mid-2013; the Murdoch family retains voting control of both entities.",
          img: "foxsports"),
    
    Story(title: "About HLN",
          category: .News,
          source: "HLN",
          description: "HLN (Headline News) is an American pay television news channel that is owned by CNN. Originally branded as CNN2, and later CNN Headline News, the channel was originally structured to broadcast a tightly-formatted 30-minute newswheel 24 hours a day, with freshly updated information that briefly covered various areas of interest (such as national news, sports, entertainment, weather and business). Since 2005, however, its format has increasingly shifted to long-form tabloid-, opinion-, crime-, and entertainment news-related programming.",
          img: "hln"),
    
    Story(title: "About MSNBC",
          category: .Politics,
          source: "NBC News",
          description: "MSNBC is an American pay television network that provides news coverage and political commentary from NBC News on current events. MSNBC is owned by the NBCUniversal News Group, a unit of the NBCUniversal Television Group division of NBCUniversal (all of which are ultimately owned by Comcast). MSNBC and its website were founded in 1996 under a partnership between Microsoft and General Electric's NBC unit, hence the network's naming.",
          img: "msnbc1"),
    Story(title: "About SKY News",
          category: .News,
          source: "SKY News",
          description: "Sky News is a British news organisation, which operates a TV network of the same name, a radio news service, and distributes news through online channels. It is owned by Sky, a division of Comcast. John Ryley is the Head of Sky News, a role he has held since June 2006. Sky News is currently Royal Television Society News Channel of the Year, the eleventh time it has held the award.",
          img: "skynews")]
