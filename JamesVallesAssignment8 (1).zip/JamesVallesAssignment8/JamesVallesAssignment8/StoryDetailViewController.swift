//
//  StoryDetailViewController.swift
//  JamesVallesAssignment8
//
//  Created by James Valles on 3/10/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class StoryDetailViewController: UIViewController {

    var data: Story?

    
    @IBOutlet weak var storyDescription: UITextView!
    @IBOutlet weak var storyTitle: UILabel!
    
    @IBOutlet weak var storySource: UILabel!

    @IBOutlet weak var storyImage: UIImageView!
    
    override func viewWillAppear(_ animated: Bool) {
        storyTitle.text = data?.title
        storyDescription.text = data?.description
      //  storySource.text = data?.source
     //   storyCategory.text = (data?.category).map { $0.rawValue }
        storyImage.image = UIImage(named: data!.img)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}
