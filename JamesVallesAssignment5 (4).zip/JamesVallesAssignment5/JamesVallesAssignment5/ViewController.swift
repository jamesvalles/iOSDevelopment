//
//  ViewController.swift
//  JamesVallesAssignment5
//
//  Created by James Valles on 2/11/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

//Added functionality to hide keyboard when, you click on any of the buttons, also when you touch down on lower part of screen.

import UIKit

var shoppingList = [String: String]()
var noItem: Bool = true

class ViewController: UIViewController {
    
    @IBOutlet var textFields: [UITextField]!
    @IBOutlet weak var itemsDisplay: UILabel!
    
    //Add item actions
    @IBAction func addItem(_ sender: Any) {
        hideKeyboard()
        addItem()
        updateLabel()
    }
    
    //New item actions
    @IBAction func newItem(_ sender: Any) {
        hideKeyboard()
        clearFields()
    }
    
    //New list actions
    @IBAction func newList(_ sender: Any) {
        hideKeyboard()
        clearFields()
        noItem = true
        itemsDisplay.text = "No items."
    
    }
    
    //Add item to list
    func addItem() {
        
        var description: String?
        var quantity: String?
        
     
        for field in textFields {
            
            if field.text == nil {
                showAlert()
                noItem = true
                break;
            }
            if field.tag == 1 {
                description = field.text
            } else {
                if Int(field.text!) == nil {
                    showAlert()
                    break;
                } else {
                    quantity = field.text
                    shoppingList[description!] = quantity!
                }
               
            }
          
        }
       //can uncomment to have it auto clear once u add new item, instead of having it hit new item button clearFields()
    }
    
    //Updates itemDisplay label
    func updateLabel() {
        if noItem{
            noItem = false
            itemsDisplay.text = ""
        }
        
        for (item, number) in shoppingList {
            itemsDisplay.text?.append("\(number)x \(item) \n")
        }
        shoppingList.removeAll()
    }
    
    //Shows popup alerts on Invalid input
    func showAlert() {
        let alert = UIAlertController(title: "Invalid Input", message: "Please enter a valid input.", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
            NSLog("The \"OK\" alert occured.")
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    //Resigns Keyboards
    @IBAction func resignKeyboard(_ sender: Any, forEvent event: UIEvent) {
        for field in textFields {
            field.resignFirstResponder()
        }
    }
    
    //Function to hide keyboards
    func hideKeyboard(){
        for field in textFields {
            field.resignFirstResponder()
        }
    }

    
    //Clears all fields
    func clearFields() {
        for field in textFields {
            field.text = ""
        }
        
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
}



