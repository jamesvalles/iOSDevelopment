//
//  AccountNavigationViewController.swift
//  BestPrice
//


import UIKit
import Firebase

class AccountNavigationViewController: UINavigationController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
    }
}
