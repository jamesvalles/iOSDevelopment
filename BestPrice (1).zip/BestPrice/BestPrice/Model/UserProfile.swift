//
//  UserProfile.swift
//  BestPrice
//
//  Created by James Valles on 3/12/19.
//  Copyright © 2019 Harry Chen. All rights reserved.
//
//

import Foundation
import SwiftyJSON

class UserProfile: NSObject {
    var userName: String = ""
    var email: String = ""
}
