CSC471 Bestprice IOS application

Written by: James Valles, Harry Chen, William Schroeder
