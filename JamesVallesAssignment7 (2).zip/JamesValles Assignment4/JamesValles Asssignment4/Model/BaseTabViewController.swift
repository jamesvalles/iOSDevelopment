//
//  BaseTabViewController.swift
//  JamesValles Asssignment4
//
//  Created by James Valles on 3/3/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class BaseTabViewController: UITabBarController {
    
    var favConfiguration = [ObjectConfig]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        for i in 0...3 {
            favConfiguration.append(ObjectConfig(i))
        }
        favConfiguration[0].name = "ABC"
        favConfiguration[1].name = "NBC"
        favConfiguration[2].name = "CBS"
        favConfiguration[3].name = "FOX"
        favConfiguration[0].channelNumber = 7
        favConfiguration[1].channelNumber = 5
        favConfiguration[2].channelNumber = 2
        favConfiguration[3].channelNumber = 32
    }
}

