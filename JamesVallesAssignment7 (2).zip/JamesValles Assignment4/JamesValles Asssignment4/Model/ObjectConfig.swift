//
//  ObjectConfig.swift
//  JamesValles Asssignment4
//
//  Created by James Valles on 3/3/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class ObjectConfig {
    var buttonNumber = 0
    var buttonLabel = ""
    var channel = 1
    
    
    init() {
    }
    
    init(_ segmentNumber: Int) {
        self.buttonNumber = segmentNumber
    }
    
    var segment: Int {
        get {
            return buttonNumber
        }
        set {
            buttonNumber = newValue
        }
    }
    
    
    var name: String {
        get {
            return buttonLabel
        }
        set {
            buttonLabel = newValue
        }
    }
    
    
    var channelNumber: Int {
        get {
            return channel
        }
        set {
            channel = newValue
        }
    }
}

