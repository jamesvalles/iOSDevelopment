//
//  ConfigurationController.swift
//  JamesValles Asssignment4
//
//  Created by James Valles on 3/2/19.
//  Copyright © 2019 DPU James Valles. All rights reserved.
//

import UIKit

class ConfigurationController: UIViewController {
    
    @IBOutlet weak var labelTextField: UITextField!
    @IBOutlet weak var buttonSelector: UISegmentedControl!
    @IBOutlet weak var channelStepper: UIStepper!
    @IBOutlet weak var save: UIButton!
    @IBOutlet weak var cancel: UIButton!
    @IBOutlet weak var stepperValue: UILabel!
    
    @IBAction func sendInfo(_ sender: Any) {
        
        let baseView = tabBarController as! BaseTabViewController
        let segmentIndex = buttonSelector.selectedSegmentIndex
        
        if labelTextField.text != "" && Int(labelTextField.text!) == nil {
            
            let favLabel = labelTextField.text!
            
            if favLabel.count > 1 && favLabel.count < 4 {
                baseView.favConfiguration[segmentIndex].name = labelTextField.text!
                baseView.favConfiguration[segmentIndex].channelNumber = Int(stepperValue.text!) ?? 1
            } else if favLabel.count <= 1 {
                alertNameTooSmall()
            } else {
                alertNameTooLong()
            }
            
        } else {
            alertBlankEntry()
        }
        
    }
    
    
    @IBAction func cancel(_ sender: Any) {
        labelTextField.text = ""
        stepperValue.text = "1"
        channelStepper.value = 1
        buttonSelector.selectedSegmentIndex = 0
        
    }
    
    @IBAction func stepper(_ sender: Any) {
        stepperValue.text = String(Int(channelStepper.value))
    }
    
    //Resigns keyboard when "Done" is pressed on keyboard.
    @IBAction func resignTextField(_ sender: UITextField) {
        sender.resignFirstResponder()
    }
    
    func alertNameTooLong() {
        let alertController = UIAlertController(title: nil, message: "Name too long. Please try again.", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func alertNameTooSmall() {
        let alertController = UIAlertController(title: nil, message: "Name too short. Please try again.", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    func alertBlankEntry() {
        let alertController = UIAlertController(title: nil, message: "Invalid. Please enter your favorite station.", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

